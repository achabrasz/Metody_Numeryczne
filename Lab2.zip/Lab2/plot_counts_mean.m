function plot_counts_mean(counts_mean)
plot(counts_mean)
title("Circle Areas");
xlabel("Circle");
ylabel("Mean");

%print -dpng zadanie5.png  
end