function plot_PageRank(r)
bar(r);
xlabel("Wezel");
ylabel("PR");
title("Page Rank");
%print -dpng zadanie7.png 
end