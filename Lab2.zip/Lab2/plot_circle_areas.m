function plot_circle_areas(circle_areas)
plot(circle_areas)
title("Circle Areas");
xlabel("Circle");
ylabel("Areas");

%print -dpng zadanie3.png 
end