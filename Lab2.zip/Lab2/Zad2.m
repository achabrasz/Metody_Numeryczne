r_max = 2;
n_max = 200;
a = 4;
[circles, index_number, circle_areas] = generate_circles(a, r_max, n_max);
circle_areas