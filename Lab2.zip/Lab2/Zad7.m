[numer_indeksu, Edges, I, B, A, b, r] = page_rank()
plot_PageRank(r)